If you want to put this on a default P+ 2.3.2 build, drag the Project+ folder in the "Drag-and-Drop Installation (P+ 2.3.2)" folder to the root of your sd card. This will replace:

RSBE01.GCT (from rebuilding the codeset due to a new code)
sc_selmap.pac (with all the necessary edits to display the STCs)
Masquerade.asm in Source/LegacyTE (where the new code is kept)

If you have custom skins installed on your build already, it is recommended to use the files in the "Manual Installation" folder. A guide on how to install this mod is provided in the folder.

Mod features:
Will display all 50 costume's STCs in the upper left corner of the SSS correctly. 
Hides the "P1" through "P4" text if the port is unused

Special thanks to QuickLava for this code. This wouldn't be possible without him